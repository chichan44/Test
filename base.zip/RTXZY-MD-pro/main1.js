function _0xb8aa(_0x207c2d, _0x1fa868) {
    const _0x294803 = _0x2948();
    return _0xb8aa = function(_0xb8aa3, _0x540fb5) {
        _0xb8aa3 = _0xb8aa3 - 0x16c;
        let _0x1a69a4 = _0x294803[_0xb8aa3];
        return _0x1a69a4;
    }, _0xb8aa(_0x207c2d, _0x1fa868);
}

function _0x2948() {
    const _0x53bd03 = ['Quick\x20Test\x20Done', 'DATABASE', '2837475oizpYf', 'chain', 'test', '38213DdjiWk', 'messages.upsert', 'fromEntries', 'uncaughtException', 'loggedOut', 'object', 'buttonsMessage', 'error', 'connect', 'readFileSync', './lib/mongoDB', '77068JcBSWV', 'slice', 'race', 'entries', 'readdirSync', 'Please\x20install\x20ffmpeg\x20for\x20sending\x20videos\x20(pkg\x20install\x20ffmpeg)', 'bind', 'spawn', 'freeze', 'map', 'path', '-amin', 'length', '1575JjUgJG', 'timestamp', 'close', 'magick', '1903320VUvyfn', 'parse', 'find', 'database.json', '43936iaaXua', 'lowdb', 'prefix', '@user\x20sekarang\x20bukan\x20admin!', '@adiwajshing/baileys', 'creds.update', 'off', 'message.delete', './lib/simple', 'ffmpeg', '130TQNLKW', 'Bot\x20connection\x20update鉁旓笍', 'templateMessage', 'reload', '--version', 'APIKeys', 'localeCompare', 'forEach', '162hDTPDP', 'tmp', 'then', 'conn', 'support', 'tmpdir', 'pino', 'statusCode', 'ffmpegWebp', 'APIs', '9750870Kxfnwi', 'loadDatabase', 'delete', 'Stickers\x20may\x20not\x20animated\x20without\x20libwebp\x20on\x20ffmpeg\x20(--enable-ibwebp\x20while\x20compiling\x20ffmpeg)', 'yargs/yargs', 'connection.update', 'write', 'syntax\x20error\x20while\x20loading\x20\x27', 'cache', 'makeWASocket', '-frames:v', 'promote', './lib/lowdb', 'warn', 'Stickers\x20may\x20not\x20work\x20without\x20imagemagick\x20if\x20libwebp\x20on\x20ffmpeg\x20doesnt\x20isntalled\x20(pkg\x20install\x20imagemagick)', 'argv', 'filter', 'reloadHandler', '898vmElME', 'PORT', 'catch', 'participantsUpdate', '-hide_banner', 'receivedPendingNotifications', 'bye', 'convert', 'output', 'keys', 'done', '@user\x20sekarang\x20admin!', 'deleted\x20plugin\x20\x27', 'data', 're\x20-\x20require\x20plugin\x20\x27', 'read', 'READ', 'onDelete', 'Selamat\x20datang\x20@user\x20di\x20group\x20@subject\x20utamakan\x20baca\x20desk\x20ya\x20\x0a@desc', 'readyState', 'demote', 'logger', 'credsUpdate', 'handler', 'info', 'join', 'log', 'env', 'replace', 'sessions', './config', 'requiring\x20new\x20plugin\x20\x27', 'Safari', 'lodash', 'watch', 'resolve', 'isBuffer', 'connectionUpdate', '62813958616959@s.whatsapp.net', 'group-participants.update', 'plugins', '鈥巟zXZ/i!#$%+拢垄鈧掳=露鈭喢椕废�鈭氣湏漏庐:;?&.\x5c-'];
    _0x2948 = function() {
        return _0x53bd03;
    };
    return _0x2948();
}(function(_0x579028, _0x42d453) {
    const _0x307b10 = _0xb8aa,
        _0x581163 = _0x579028();
    while (!![]) {
        try {
            const _0xa91be3 = -parseInt(_0x307b10(0x194)) / 0x1 + -parseInt(_0x307b10(0x1c2)) / 0x2 * (-parseInt(_0x307b10(0x18c)) / 0x3) + parseInt(_0x307b10(0x17f)) / 0x4 * (-parseInt(_0x307b10(0x19e)) / 0x5) + -parseInt(_0x307b10(0x1a6)) / 0x6 * (-parseInt(_0x307b10(0x174)) / 0x7) + -parseInt(_0x307b10(0x190)) / 0x8 + -parseInt(_0x307b10(0x171)) / 0x9 + parseInt(_0x307b10(0x1b0)) / 0xa;
            if (_0xa91be3 === _0x42d453) break;
            else _0x581163['push'](_0x581163['shift']());
        } catch (_0x6a6401) {
            _0x581163['push'](_0x581163['shift']());
        }
    }
}(_0x2948, 0x3f829), ((async () => {
    const _0x491fe9 = _0xb8aa;
    require(_0x491fe9(0x1e0));
    const {
        useMultiFileAuthState: _0x57f712,
        DisconnectReason: _0x3c602c,
        generateForwardMessageContent: _0x24f7eb,
        prepareWAMessageMedia: _0x2ace04,
        generateWAMessageFromContent: _0x5ae749,
        generateMessageID: _0x27f5ab,
        downloadContentFromMessage: _0x352fc8,
        makeInMemoryStore: _0x26c979,
        jidDecode: _0x4f6d96,
        proto: _0x27eadd
    } = require(_0x491fe9(0x198)), _0x43aa65 = require(_0x491fe9(0x1ac)), _0xd927ac = require('ws'), _0x57e0df = require(_0x491fe9(0x189)), _0x4498b9 = require('fs'), _0x2ea916 = require(_0x491fe9(0x1b4)), _0x494e9c = require('child_process'), _0x1b2185 = require(_0x491fe9(0x1e3)), _0x3166fd = require('syntax-error'), _0x4aa2ee = require(_0x491fe9(0x1ac)), _0x420c3d = require('os');
    let _0x226be0 = require(_0x491fe9(0x19c));
    var _0x340c49;
    try {
        _0x340c49 = require(_0x491fe9(0x195));
    } catch (_0x10354a) {
        _0x340c49 = require(_0x491fe9(0x1bc));
    }
    const {
        Low: _0x24a7c1,
        JSONFile: _0x1a5b15
    } = _0x340c49, _0x529f7d = require(_0x491fe9(0x17e));
    global['API'] = (_0x3b3964, _0x48879a = '/', _0xa769c9 = {}, _0x1af8c0) => (_0x3b3964 in global[_0x491fe9(0x1af)] ? global['APIs'][_0x3b3964] : _0x3b3964) + _0x48879a + (_0xa769c9 || _0x1af8c0 ? '?' + new URLSearchParams(Object[_0x491fe9(0x182)]({
        ..._0xa769c9,
        ..._0x1af8c0 ? {
            [_0x1af8c0]: global[_0x491fe9(0x1a3)][_0x3b3964 in global[_0x491fe9(0x1af)] ? global[_0x491fe9(0x1af)][_0x3b3964] : _0x3b3964]
        } : {}
    })) : ''), global[_0x491fe9(0x18d)] = {
        'start': new Date()
    };
    const _0x42b550 = process[_0x491fe9(0x1dd)][_0x491fe9(0x1c3)] || 0xbb8;
    global['opts'] = new Object(_0x2ea916(process[_0x491fe9(0x1bf)][_0x491fe9(0x180)](0x2))['exitProcess'](![])[_0x491fe9(0x191)]()), global[_0x491fe9(0x196)] = new RegExp('^[' + (opts[_0x491fe9(0x196)] || _0x491fe9(0x16e))[_0x491fe9(0x1de)](/[|\\{}()[\]^$+*?.\-\^]/g, '\x5c$&') + ']'), global['db'] = new _0x24a7c1(/https?:\/\// [_0x491fe9(0x173)](opts['db'] || '') ? new cloudDBAdapter(opts['db']) : /mongodb/ ['test'](opts['db']) ? new _0x529f7d(opts['db']) : new _0x1a5b15((opts['_'][0x0] ? opts['_'][0x0] + '_' : '') + _0x491fe9(0x193))), global[_0x491fe9(0x170)] = global['db'], global[_0x491fe9(0x1b1)] = async function _0x289585() {
        const _0x489841 = _0x491fe9;
        if (global['db'][_0x489841(0x1d2)]) return new Promise(_0x4162da => setInterval(function() {
            const _0x3daffb = _0x489841;
            !global['db']['READ'] ? (clearInterval(this), _0x4162da(global['db'][_0x3daffb(0x1cf)] == null ? global[_0x3daffb(0x1b1)]() : global['db']['data'])) : null;
        }, 0x1 * 0x3e8));
        if (global['db'][_0x489841(0x1cf)] !== null) return;
        global['db'][_0x489841(0x1d2)] = !![], await global['db'][_0x489841(0x1d1)](), global['db'][_0x489841(0x1d2)] = ![], global['db'][_0x489841(0x1cf)] = {
            'users': {},
            'chats': {},
            'stats': {},
            'msgs': {},
            'sticker': {},
            ...global['db']['data'] || {}
        }, global['db'][_0x489841(0x172)] = _0x1b2185[_0x489841(0x172)](global['db']['data']);
    }, loadDatabase();
    const _0x5dd4b4 = '' + (opts['_'][0x0] || _0x491fe9(0x1df));
    global['isInit'] = !_0x4498b9['existsSync'](_0x5dd4b4);
    const {
        state: _0x38b0fa,
        saveState: _0x34c058,
        saveCreds: _0x25de96
    } = await _0x57f712(_0x5dd4b4), _0x1fb42a = {
        'printQRInTerminal': !![],
        'syncFullHistory': !![],
        'markOnlineOnConnect': !![],
        'connectTimeoutMs': 0xea60,
        'defaultQueryTimeoutMs': 0x0,
        'keepAliveIntervalMs': 0x2710,
        'generateHighQualityLinkPreview': !![],
        'patchMessageBeforeSending': _0x2e790f => {
            const _0xf8bdd = _0x491fe9,
                _0x4e5f9b = !!(_0x2e790f[_0xf8bdd(0x17a)] || _0x2e790f[_0xf8bdd(0x1a0)] || _0x2e790f['listMessage']);
            return _0x4e5f9b && (_0x2e790f = {
                'viewOnceMessage': {
                    'message': {
                        'messageContextInfo': {
                            'deviceListMetadataVersion': 0x2,
                            'deviceListMetadata': {}
                        },
                        ..._0x2e790f
                    }
                }
            }), _0x2e790f;
        },
        'auth': _0x38b0fa,
        'browser': ['BOTCAHX', _0x491fe9(0x1e2), ''],
        'logger': _0x43aa65({
            'level': 'silent'
        }),
        'version': [0x2, 0x913, 0x4]
    };
    global['conn'] = _0x226be0[_0x491fe9(0x1b9)](_0x1fb42a);
    if (!opts[_0x491fe9(0x173)]) {
        if (global['db']) setInterval(async () => {
            const _0x4cee06 = _0x491fe9;
            if (global['db'][_0x4cee06(0x1cf)]) await global['db'][_0x4cee06(0x1b6)]();
            if (!opts['tmp'] && (global[_0x4cee06(0x1aa)] || {})['find']) tmp = [_0x420c3d[_0x4cee06(0x1ab)](), _0x4cee06(0x1a7)], tmp[_0x4cee06(0x1a5)](_0x133812 => _0x494e9c['spawn']('find', [_0x133812, _0x4cee06(0x18a), '3', '-type', 'f', '-delete']));
        }, 0x1e * 0x3e8);
    }
    async function _0x427efd(_0x51bc45) {
        const _0x1a50ce = _0x491fe9,
            {
                connection: _0x60cd8c,
                lastDisconnect: _0x544b1a
            } = _0x51bc45;
        global[_0x1a50ce(0x18d)][_0x1a50ce(0x17c)] = new Date();
        _0x544b1a && _0x544b1a[_0x1a50ce(0x17b)] && _0x544b1a['error']['output'] && _0x544b1a[_0x1a50ce(0x17b)][_0x1a50ce(0x1ca)][_0x1a50ce(0x1ad)] !== _0x3c602c[_0x1a50ce(0x178)] && conn['ws'][_0x1a50ce(0x1d5)] !== _0xd927ac['CONNECTING'] && console[_0x1a50ce(0x1dc)](global[_0x1a50ce(0x1c1)](!![]));
        if (global['db']['data'] == null) await loadDatabase();
        if (_0x51bc45[_0x1a50ce(0x1c7)]) conn['sendMessage'](_0x1a50ce(0x1e8), {
            'text': _0x1a50ce(0x19f)
        }, {
            'quoted': null
        });
    }
    process['on'](_0x491fe9(0x177), console[_0x491fe9(0x17b)]);
    const _0x2d59cc = _0x2b1925 => {
        const _0x221c99 = _0x491fe9;
        _0x2b1925 = require[_0x221c99(0x1e5)](_0x2b1925);
        let _0x1363ce, _0x576d7a = 0x0;
        do {
            if (_0x2b1925 in require[_0x221c99(0x1b8)]) delete require[_0x221c99(0x1b8)][_0x2b1925];
            _0x1363ce = require(_0x2b1925), _0x576d7a++;
        } while ((!_0x1363ce || (Array['isArray'](_0x1363ce) || _0x1363ce instanceof String) ? !(_0x1363ce || [])[_0x221c99(0x18b)] : typeof _0x1363ce == _0x221c99(0x179) && !Buffer[_0x221c99(0x1e6)](_0x1363ce) ? !Object[_0x221c99(0x1cb)](_0x1363ce || {})[_0x221c99(0x18b)] : !![]) && _0x576d7a <= 0xa);
        return _0x1363ce;
    };
    let _0x2ab3bc = !![];
    global[_0x491fe9(0x1c1)] = function(_0x5868d0) {
        const _0x5955a1 = _0x491fe9;
        let _0x56dc90 = _0x2d59cc('./handler');
        if (_0x5868d0) {
            try {
                global[_0x5955a1(0x1a9)]['ws'][_0x5955a1(0x18e)]();
            } catch {}
            global[_0x5955a1(0x1a9)] = {
                ...global[_0x5955a1(0x1a9)],
                ..._0x226be0[_0x5955a1(0x1b9)](_0x1fb42a)
            };
        }
        return !_0x2ab3bc && (conn['ev'][_0x5955a1(0x19a)](_0x5955a1(0x175), conn[_0x5955a1(0x1d9)]), conn['ev'][_0x5955a1(0x19a)](_0x5955a1(0x16c), conn[_0x5955a1(0x1c5)]), conn['ev'][_0x5955a1(0x19a)]('message.delete', conn[_0x5955a1(0x1d3)]), conn['ev'][_0x5955a1(0x19a)](_0x5955a1(0x1b5), conn['connectionUpdate']), conn['ev'][_0x5955a1(0x19a)]('creds.update', conn[_0x5955a1(0x1d8)])), conn['welcome'] = _0x5955a1(0x1d4), conn[_0x5955a1(0x1c8)] = 'Selamat\x20tinggal\x20@user\x20馃憢', conn[_0x5955a1(0x1bb)] = _0x5955a1(0x1cd), conn[_0x5955a1(0x1d6)] = _0x5955a1(0x197), conn[_0x5955a1(0x1d9)] = _0x56dc90['handler']['bind'](conn), conn['participantsUpdate'] = _0x56dc90['participantsUpdate'][_0x5955a1(0x185)](conn), conn[_0x5955a1(0x1d3)] = _0x56dc90[_0x5955a1(0x1b2)]['bind'](conn), conn[_0x5955a1(0x1e7)] = _0x427efd['bind'](conn), conn[_0x5955a1(0x1d8)] = _0x25de96['bind'](conn), conn['ev']['on'](_0x5955a1(0x175), conn[_0x5955a1(0x1d9)]), conn['ev']['on'](_0x5955a1(0x16c), conn[_0x5955a1(0x1c5)]), conn['ev']['on'](_0x5955a1(0x19b), conn['onDelete']), conn['ev']['on'](_0x5955a1(0x1b5), conn[_0x5955a1(0x1e7)]), conn['ev']['on'](_0x5955a1(0x199), conn['credsUpdate']), _0x2ab3bc = ![], !![];
    };
    let _0xb8f4a = _0x57e0df['join'](__dirname, _0x491fe9(0x16d)),
        _0x5e5343 = _0x2135dd => /\.js$/ [_0x491fe9(0x173)](_0x2135dd);
    global[_0x491fe9(0x16d)] = {};
    for (let _0x337b9f of _0x4498b9[_0x491fe9(0x183)](_0xb8f4a)[_0x491fe9(0x1c0)](_0x5e5343)) {
        try {
            global[_0x491fe9(0x16d)][_0x337b9f] = require(_0x57e0df[_0x491fe9(0x1db)](_0xb8f4a, _0x337b9f));
        } catch (_0x50644d) {
            conn[_0x491fe9(0x1d7)][_0x491fe9(0x17b)](_0x50644d), delete global[_0x491fe9(0x16d)][_0x337b9f];
        }
    }
    console['log'](Object[_0x491fe9(0x1cb)](global[_0x491fe9(0x16d)])), global['reload'] = (_0xd23263, _0x3fc28a) => {
        const _0x26d6d6 = _0x491fe9;
        if (_0x5e5343(_0x3fc28a)) {
            let _0x4671ca = _0x57e0df['join'](_0xb8f4a, _0x3fc28a);
            if (_0x4671ca in require[_0x26d6d6(0x1b8)]) {
                delete require[_0x26d6d6(0x1b8)][_0x4671ca];
                if (_0x4498b9['existsSync'](_0x4671ca)) conn['logger'][_0x26d6d6(0x1da)](_0x26d6d6(0x1d0) + _0x3fc28a + '\x27');
                else return conn['logger'][_0x26d6d6(0x1bd)](_0x26d6d6(0x1ce) + _0x3fc28a + '\x27'), delete global['plugins'][_0x3fc28a];
            } else conn[_0x26d6d6(0x1d7)][_0x26d6d6(0x1da)](_0x26d6d6(0x1e1) + _0x3fc28a + '\x27');
            let _0x513f87 = _0x3166fd(_0x4498b9[_0x26d6d6(0x17d)](_0x4671ca), _0x3fc28a);
            if (_0x513f87) conn[_0x26d6d6(0x1d7)][_0x26d6d6(0x17b)](_0x26d6d6(0x1b7) + _0x3fc28a + '\x27\x0a' + _0x513f87);
            else try {
                global[_0x26d6d6(0x16d)][_0x3fc28a] = require(_0x4671ca);
            } catch (_0x285a48) {
                conn['logger'][_0x26d6d6(0x17b)](_0x285a48);
            } finally {
                global[_0x26d6d6(0x16d)] = Object[_0x26d6d6(0x176)](Object[_0x26d6d6(0x182)](global['plugins'])['sort'](([_0x3dbd0d], [_0x40accd]) => _0x3dbd0d[_0x26d6d6(0x1a4)](_0x40accd)));
            }
        }
    }, Object['freeze'](global[_0x491fe9(0x1a1)]), _0x4498b9[_0x491fe9(0x1e4)](_0x57e0df[_0x491fe9(0x1db)](__dirname, _0x491fe9(0x16d)), global[_0x491fe9(0x1a1)]), global['reloadHandler']();
    async function _0x5e3f76() {
        const _0x2fc000 = _0x491fe9;
        let _0xaafee2 = await Promise['all']([_0x494e9c[_0x2fc000(0x186)](_0x2fc000(0x19d)), _0x494e9c[_0x2fc000(0x186)]('ffprobe'), _0x494e9c[_0x2fc000(0x186)](_0x2fc000(0x19d), [_0x2fc000(0x1c6), '-loglevel', _0x2fc000(0x17b), '-filter_complex', 'color', _0x2fc000(0x1ba), '1', '-f', 'webp', '-']), _0x494e9c['spawn'](_0x2fc000(0x1c9)), _0x494e9c[_0x2fc000(0x186)](_0x2fc000(0x18f)), _0x494e9c[_0x2fc000(0x186)]('gm'), _0x494e9c[_0x2fc000(0x186)](_0x2fc000(0x192), [_0x2fc000(0x1a2)])][_0x2fc000(0x188)](_0x18cc5e => {
                const _0x14a873 = _0x2fc000;
                return Promise[_0x14a873(0x181)]([new Promise(_0xc99612 => {
                    const _0x216a43 = _0x14a873;
                    _0x18cc5e['on'](_0x216a43(0x18e), _0xc1bda2 => {
                        _0xc99612(_0xc1bda2 !== 0x7f);
                    });
                }), new Promise(_0x55b07a => {
                    const _0x4ea228 = _0x14a873;
                    _0x18cc5e['on'](_0x4ea228(0x17b), _0xd5ff1c => _0x55b07a(![]));
                })]);
            })),
            [_0x3280ca, _0x307b0f, _0x4362b7, _0x263834, _0x14c712, _0x35b647, _0x352ae4] = _0xaafee2;
        console[_0x2fc000(0x1dc)](_0xaafee2);
        let _0x5405b3 = global[_0x2fc000(0x1aa)] = {
            'ffmpeg': _0x3280ca,
            'ffprobe': _0x307b0f,
            'ffmpegWebp': _0x4362b7,
            'convert': _0x263834,
            'magick': _0x14c712,
            'gm': _0x35b647,
            'find': _0x352ae4
        };
        Object[_0x2fc000(0x187)](global['support']);
        if (!_0x5405b3['ffmpeg']) conn[_0x2fc000(0x1d7)][_0x2fc000(0x1bd)](_0x2fc000(0x184));
        if (_0x5405b3[_0x2fc000(0x19d)] && !_0x5405b3[_0x2fc000(0x1ae)]) conn['logger']['warn'](_0x2fc000(0x1b3));
        if (!_0x5405b3['convert'] && !_0x5405b3['magick'] && !_0x5405b3['gm']) conn[_0x2fc000(0x1d7)][_0x2fc000(0x1bd)](_0x2fc000(0x1be));
    }
    _0x5e3f76()[_0x491fe9(0x1a8)](() => conn['logger'][_0x491fe9(0x1da)](_0x491fe9(0x16f)))[_0x491fe9(0x1c4)](_0x491fe9(0x1cc));
})()));